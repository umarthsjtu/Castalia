#ifndef _SMARTROUTING_H_
#define _SMARTROUTING_H_

#include "VirtualRouting.h"
#include "SmartRoutingPacket_m.h"

using namespace std;

class SmartRouting: public VirtualRouting {
 private:
	double netSetupTime;

	int numhop;

 protected:
	void fromApplicationLayer(cPacket *, const char *);
	void fromMacLayer(cPacket *, int, double, double);
        void startup();
        string getnexthop(const char *);
};

#endif	
