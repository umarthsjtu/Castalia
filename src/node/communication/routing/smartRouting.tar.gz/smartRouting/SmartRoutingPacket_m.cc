//
// Generated file, do not edit! Created by opp_msgc 4.2 from src/node/communication/routing/smartRouting/SmartRoutingPacket.msg.
//

// Disable warnings about unused variables, empty switch stmts, etc:
#ifdef _MSC_VER
#  pragma warning(disable:4101)
#  pragma warning(disable:4065)
#endif

#include <iostream>
#include <sstream>
#include "SmartRoutingPacket_m.h"

// Template rule which fires if a struct or class doesn't have operator<<
template<typename T>
std::ostream& operator<<(std::ostream& out,const T&) {return out;}

// Another default rule (prevents compiler from choosing base class' doPacking())
template<typename T>
void doPacking(cCommBuffer *, T& t) {
    throw cRuntimeError("Parsim error: no doPacking() function for type %s or its base class (check .msg and _m.cc/h files!)",opp_typename(typeid(t)));
}

template<typename T>
void doUnpacking(cCommBuffer *, T& t) {
    throw cRuntimeError("Parsim error: no doUnpacking() function for type %s or its base class (check .msg and _m.cc/h files!)",opp_typename(typeid(t)));
}




EXECUTE_ON_STARTUP(
    cEnum *e = cEnum::find("SmartRoutingPacketDef");
    if (!e) enums.getInstance()->add(e = new cEnum("SmartRoutingPacketDef"));
    e->insert(SMART_DATA_PACKET, "SMART_DATA_PACKET");
    e->insert(SMART_ACK_PACKET, "SMART_ACK_PACKET");
    e->insert(SMART_DROP_PACKET, "SMART_DROP_PACKET");
);

Register_Class(SmartRoutingPacket);

SmartRoutingPacket::SmartRoutingPacket(const char *name, int kind) : RoutingPacket(name,kind)
{
    this->SmartRoutingPacketKind_var = 0;
    this->RSSI_var = 0;
    this->LQI_var = 0;
    this->nexthop_var = 0;
    this->source_var = 0;
    this->destination_var = 0;
}

SmartRoutingPacket::SmartRoutingPacket(const SmartRoutingPacket& other) : RoutingPacket(other)
{
    copy(other);
}

SmartRoutingPacket::~SmartRoutingPacket()
{
}

SmartRoutingPacket& SmartRoutingPacket::operator=(const SmartRoutingPacket& other)
{
    if (this==&other) return *this;
    RoutingPacket::operator=(other);
    copy(other);
    return *this;
}

void SmartRoutingPacket::copy(const SmartRoutingPacket& other)
{
    this->SmartRoutingPacketKind_var = other.SmartRoutingPacketKind_var;
    this->RSSI_var = other.RSSI_var;
    this->LQI_var = other.LQI_var;
    this->nexthop_var = other.nexthop_var;
    this->source_var = other.source_var;
    this->destination_var = other.destination_var;
}

void SmartRoutingPacket::parsimPack(cCommBuffer *b)
{
    RoutingPacket::parsimPack(b);
    doPacking(b,this->SmartRoutingPacketKind_var);
    doPacking(b,this->RSSI_var);
    doPacking(b,this->LQI_var);
    doPacking(b,this->nexthop_var);
    doPacking(b,this->source_var);
    doPacking(b,this->destination_var);
}

void SmartRoutingPacket::parsimUnpack(cCommBuffer *b)
{
    RoutingPacket::parsimUnpack(b);
    doUnpacking(b,this->SmartRoutingPacketKind_var);
    doUnpacking(b,this->RSSI_var);
    doUnpacking(b,this->LQI_var);
    doUnpacking(b,this->nexthop_var);
    doUnpacking(b,this->source_var);
    doUnpacking(b,this->destination_var);
}

int SmartRoutingPacket::getSmartRoutingPacketKind() const
{
    return SmartRoutingPacketKind_var;
}

void SmartRoutingPacket::setSmartRoutingPacketKind(int SmartRoutingPacketKind)
{
    this->SmartRoutingPacketKind_var = SmartRoutingPacketKind;
}

double SmartRoutingPacket::getRSSI() const
{
    return RSSI_var;
}

void SmartRoutingPacket::setRSSI(double RSSI)
{
    this->RSSI_var = RSSI;
}

double SmartRoutingPacket::getLQI() const
{
    return LQI_var;
}

void SmartRoutingPacket::setLQI(double LQI)
{
    this->LQI_var = LQI;
}

const char * SmartRoutingPacket::getNexthop() const
{
    return nexthop_var.c_str();
}

void SmartRoutingPacket::setNexthop(const char * nexthop)
{
    this->nexthop_var = nexthop;
}

const char * SmartRoutingPacket::getSource() const
{
    return source_var.c_str();
}

void SmartRoutingPacket::setSource(const char * source)
{
    this->source_var = source;
}

const char * SmartRoutingPacket::getDestination() const
{
    return destination_var.c_str();
}

void SmartRoutingPacket::setDestination(const char * destination)
{
    this->destination_var = destination;
}

class SmartRoutingPacketDescriptor : public cClassDescriptor
{
  public:
    SmartRoutingPacketDescriptor();
    virtual ~SmartRoutingPacketDescriptor();

    virtual bool doesSupport(cObject *obj) const;
    virtual const char *getProperty(const char *propertyname) const;
    virtual int getFieldCount(void *object) const;
    virtual const char *getFieldName(void *object, int field) const;
    virtual int findField(void *object, const char *fieldName) const;
    virtual unsigned int getFieldTypeFlags(void *object, int field) const;
    virtual const char *getFieldTypeString(void *object, int field) const;
    virtual const char *getFieldProperty(void *object, int field, const char *propertyname) const;
    virtual int getArraySize(void *object, int field) const;

    virtual std::string getFieldAsString(void *object, int field, int i) const;
    virtual bool setFieldAsString(void *object, int field, int i, const char *value) const;

    virtual const char *getFieldStructName(void *object, int field) const;
    virtual void *getFieldStructPointer(void *object, int field, int i) const;
};

Register_ClassDescriptor(SmartRoutingPacketDescriptor);

SmartRoutingPacketDescriptor::SmartRoutingPacketDescriptor() : cClassDescriptor("SmartRoutingPacket", "RoutingPacket")
{
}

SmartRoutingPacketDescriptor::~SmartRoutingPacketDescriptor()
{
}

bool SmartRoutingPacketDescriptor::doesSupport(cObject *obj) const
{
    return dynamic_cast<SmartRoutingPacket *>(obj)!=NULL;
}

const char *SmartRoutingPacketDescriptor::getProperty(const char *propertyname) const
{
    cClassDescriptor *basedesc = getBaseClassDescriptor();
    return basedesc ? basedesc->getProperty(propertyname) : NULL;
}

int SmartRoutingPacketDescriptor::getFieldCount(void *object) const
{
    cClassDescriptor *basedesc = getBaseClassDescriptor();
    return basedesc ? 6+basedesc->getFieldCount(object) : 6;
}

unsigned int SmartRoutingPacketDescriptor::getFieldTypeFlags(void *object, int field) const
{
    cClassDescriptor *basedesc = getBaseClassDescriptor();
    if (basedesc) {
        if (field < basedesc->getFieldCount(object))
            return basedesc->getFieldTypeFlags(object, field);
        field -= basedesc->getFieldCount(object);
    }
    static unsigned int fieldTypeFlags[] = {
        FD_ISEDITABLE,
        FD_ISEDITABLE,
        FD_ISEDITABLE,
        FD_ISEDITABLE,
        FD_ISEDITABLE,
        FD_ISEDITABLE,
    };
    return (field>=0 && field<6) ? fieldTypeFlags[field] : 0;
}

const char *SmartRoutingPacketDescriptor::getFieldName(void *object, int field) const
{
    cClassDescriptor *basedesc = getBaseClassDescriptor();
    if (basedesc) {
        if (field < basedesc->getFieldCount(object))
            return basedesc->getFieldName(object, field);
        field -= basedesc->getFieldCount(object);
    }
    static const char *fieldNames[] = {
        "SmartRoutingPacketKind",
        "RSSI",
        "LQI",
        "nexthop",
        "source",
        "destination",
    };
    return (field>=0 && field<6) ? fieldNames[field] : NULL;
}

int SmartRoutingPacketDescriptor::findField(void *object, const char *fieldName) const
{
    cClassDescriptor *basedesc = getBaseClassDescriptor();
    int base = basedesc ? basedesc->getFieldCount(object) : 0;
    if (fieldName[0]=='S' && strcmp(fieldName, "SmartRoutingPacketKind")==0) return base+0;
    if (fieldName[0]=='R' && strcmp(fieldName, "RSSI")==0) return base+1;
    if (fieldName[0]=='L' && strcmp(fieldName, "LQI")==0) return base+2;
    if (fieldName[0]=='n' && strcmp(fieldName, "nexthop")==0) return base+3;
    if (fieldName[0]=='s' && strcmp(fieldName, "source")==0) return base+4;
    if (fieldName[0]=='d' && strcmp(fieldName, "destination")==0) return base+5;
    return basedesc ? basedesc->findField(object, fieldName) : -1;
}

const char *SmartRoutingPacketDescriptor::getFieldTypeString(void *object, int field) const
{
    cClassDescriptor *basedesc = getBaseClassDescriptor();
    if (basedesc) {
        if (field < basedesc->getFieldCount(object))
            return basedesc->getFieldTypeString(object, field);
        field -= basedesc->getFieldCount(object);
    }
    static const char *fieldTypeStrings[] = {
        "int",
        "double",
        "double",
        "string",
        "string",
        "string",
    };
    return (field>=0 && field<6) ? fieldTypeStrings[field] : NULL;
}

const char *SmartRoutingPacketDescriptor::getFieldProperty(void *object, int field, const char *propertyname) const
{
    cClassDescriptor *basedesc = getBaseClassDescriptor();
    if (basedesc) {
        if (field < basedesc->getFieldCount(object))
            return basedesc->getFieldProperty(object, field, propertyname);
        field -= basedesc->getFieldCount(object);
    }
    switch (field) {
        case 0:
            if (!strcmp(propertyname,"enum")) return "SmartRoutingPacketDef";
            return NULL;
        default: return NULL;
    }
}

int SmartRoutingPacketDescriptor::getArraySize(void *object, int field) const
{
    cClassDescriptor *basedesc = getBaseClassDescriptor();
    if (basedesc) {
        if (field < basedesc->getFieldCount(object))
            return basedesc->getArraySize(object, field);
        field -= basedesc->getFieldCount(object);
    }
    SmartRoutingPacket *pp = (SmartRoutingPacket *)object; (void)pp;
    switch (field) {
        default: return 0;
    }
}

std::string SmartRoutingPacketDescriptor::getFieldAsString(void *object, int field, int i) const
{
    cClassDescriptor *basedesc = getBaseClassDescriptor();
    if (basedesc) {
        if (field < basedesc->getFieldCount(object))
            return basedesc->getFieldAsString(object,field,i);
        field -= basedesc->getFieldCount(object);
    }
    SmartRoutingPacket *pp = (SmartRoutingPacket *)object; (void)pp;
    switch (field) {
        case 0: return long2string(pp->getSmartRoutingPacketKind());
        case 1: return double2string(pp->getRSSI());
        case 2: return double2string(pp->getLQI());
        case 3: return oppstring2string(pp->getNexthop());
        case 4: return oppstring2string(pp->getSource());
        case 5: return oppstring2string(pp->getDestination());
        default: return "";
    }
}

bool SmartRoutingPacketDescriptor::setFieldAsString(void *object, int field, int i, const char *value) const
{
    cClassDescriptor *basedesc = getBaseClassDescriptor();
    if (basedesc) {
        if (field < basedesc->getFieldCount(object))
            return basedesc->setFieldAsString(object,field,i,value);
        field -= basedesc->getFieldCount(object);
    }
    SmartRoutingPacket *pp = (SmartRoutingPacket *)object; (void)pp;
    switch (field) {
        case 0: pp->setSmartRoutingPacketKind(string2long(value)); return true;
        case 1: pp->setRSSI(string2double(value)); return true;
        case 2: pp->setLQI(string2double(value)); return true;
        case 3: pp->setNexthop((value)); return true;
        case 4: pp->setSource((value)); return true;
        case 5: pp->setDestination((value)); return true;
        default: return false;
    }
}

const char *SmartRoutingPacketDescriptor::getFieldStructName(void *object, int field) const
{
    cClassDescriptor *basedesc = getBaseClassDescriptor();
    if (basedesc) {
        if (field < basedesc->getFieldCount(object))
            return basedesc->getFieldStructName(object, field);
        field -= basedesc->getFieldCount(object);
    }
    static const char *fieldStructNames[] = {
        NULL,
        NULL,
        NULL,
        NULL,
        NULL,
        NULL,
    };
    return (field>=0 && field<6) ? fieldStructNames[field] : NULL;
}

void *SmartRoutingPacketDescriptor::getFieldStructPointer(void *object, int field, int i) const
{
    cClassDescriptor *basedesc = getBaseClassDescriptor();
    if (basedesc) {
        if (field < basedesc->getFieldCount(object))
            return basedesc->getFieldStructPointer(object, field, i);
        field -= basedesc->getFieldCount(object);
    }
    SmartRoutingPacket *pp = (SmartRoutingPacket *)object; (void)pp;
    switch (field) {
        default: return NULL;
    }
}


