#include "SmartRouting.h"

Define_Module(SmartRouting);

void SmartRouting::startup()
{
	netSetupTime = (double)par("netSetupTime") / 1000.0;
        //获得整个网络拓扑结构
        //建立路由表
        //建立空邻居表    	
}
void fromApplicationLayer(cPacket *, const char *)
{
	//创建网路包
        //源地址，目的地址
	//查找路由表，下一跳地址
        //跳数=1
        //把网络包交给MAC层
        //并放在本地容器里面
}
void fromMacLayer(cPacket *, int, double, double)
{
   //数据包
	//查看目的地址
        //如果是自己的，解包交给应用层
        //不是自己的，
        //查看跳数 大于5，发送DROP信息到源地址
        //查看路由表，修改下跳地址 
        //跳数+1
        //把网络包交给MAC层
   //控制包ACK
       	//查看目的地址
        //如果是自己的，查看本地容器 删除相应项
        //不是自己的，
        //查看路由表，修改下跳地址
        //把网络包交给MAC层
    //控制包DROP
        //查看目的地址
        //如果是自己的，查看本地容器，重新发包
        //不是自己的，
        //查看路由表，修改下跳地址
        //把网络包交给MAC层
     //控制包broadcast
        //发hello 数据为0
        //交给MAC层
     //控制包topology
         //更新自己的邻居表
         //+上加速度发送给topologymodule
}

string getnexthop(const char *)
{
       //发消息到topologmodule
       //updateRoutingPath
       //searchRoutingPath
       //return nexthop
}
void updateRoutingPath()
{
      //fromtopology等待路由信息
      //更新路由表
}
string searchRoutingPath(const char *)
{

}
